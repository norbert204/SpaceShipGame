#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>
#include <stdbool.h>

#include <SDL2/SDL.h>

extern float delta_time;

#endif