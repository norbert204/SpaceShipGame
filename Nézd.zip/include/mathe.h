#ifndef MATHE_H
#define MATHE_H

#define M_PI 3.14159265358979323846

#endif